package advancedJava.Ferrari;

public interface Car {

     String getModel();
    String getNameDriver();
    String pushGas();
    String gasPedal();

}
