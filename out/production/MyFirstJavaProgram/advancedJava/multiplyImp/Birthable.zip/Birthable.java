package advancedJava.multiplyImp;

public interface Birthable {

}
