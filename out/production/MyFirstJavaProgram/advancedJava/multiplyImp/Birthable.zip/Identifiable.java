package advancedJava.multiplyImp;

public interface Identifiable {
    String getId();
}
